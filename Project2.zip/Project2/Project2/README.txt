

The project is correctly working and we got the output that we are expected to get.
Our submission folder contains the README file, the python source code for each microservice, 
Procfile definitions for every service, an initialization script, a CVS schema file for every database we created,
the haproxy configuration file. The documentation for [how to create the databases and start the services]
and the [REST API documentation for each service] is included in the README file


To run this project, you should use the Tuffix 2020 platform with Python 3.8.10. Also, you have to use 
an HTTP client program such as HTTPie or curl.


__________________________________________________
Configure Tuffix 2020 to prepare for Project 2:

--Install the pip package installer and other tools by running the following commands:

	sudo apt update
	sudo apt install --yes python3-pip ruby-foreman httpie sqlite3

--Install the Hug and sqlite-utils libraries by running the following command:

	python3 -m pip install hug sqlite-utils

--Log out then back in to pick up changes to your PATH before trying to run the hug or sqlite-utils commands.

--Install the HAProxy and Gunicorn servers by running the following commands:

	sudo apt install --yes haproxy gunicorn

--Clone the GitHub Repository and experiment with the sample API:

	git clone https://github.com/ProfAvery/cpsc449.git
	cd cpsc449/hug/api

--Run the following commands to initialize the database and start the API:

	./bin/init.sh
	foreman start

--Run the following command from another terminal window to test creation of a new book:

	./bin/post.sh ./share/book.json

--Test the rest of the API calls using curl or HTTPie.

_____________________________________________________

Documentation for how to create the datbases and start the services:

Project Repo:/home/student/Project2/hug/api

Inside api/bin/init.sh, created 3 databases: users.db, followers.db and, posts.db 
Added some data in 3 csvs /home/student/Project2/hug/api/share


Run ./bin/init.sh inside /api, all 3 databases with data from csvs will be created in hug/api/var folder


Documantion for the REST API for each service:

APIs:

Users:
	GET: 
		To view all users: http get localhost:5000/users
		To view single user: http get localhost:5000/users/{id}
		Ex. http get localhost:5000/users/7
		
	POST:
		To add a new user: http post localhost:5000/users bio={} email_id={} password={}username={}
		Ex. http post localhost:5000/users bio=student4 email_id=t4@gmail.com password=student@4 username=test

Followers:
	GET: 
		To view all follwers: http get localhost:5000/followers
		
	POST:
		To add follwers: http post localhost:5000/followers follower_id={} user_id={}
		Ex. http post localhost:5000/followers follower_id=5 user_id=4
		[Conditions checked:
			1. user and follower both should exist in database
			2. User cannot follow himself]
		
	DELETE: 
		To remove followers: http delete localhost:5000/followers follower_id={} user_id={}
		Ex. http delete localhost:5000/followers follower_id=5 user_id=4

Posts:
	GET: 
		To view all posts: http get localhost:5100/posts/
		
	POST: Authentication required
		To add new posts: 
		http post localhost:5100/posts postmsg={} repost_url={} timestamp={} username={} --auth {username}:{password}
		
		Ex. http post localhost:5100/posts postmsg="Hi this is my last post" repost_url=null timestamp=10/22/2021 username=kpandit --auth kpandit:student@1
	
Timeline:
	GET:
	
	1. User timeline:  To view users posts
		http get localhost:5100/posts/usertimeline/{username}
		Ex. http get localhost:5100/posts/usertimeline/kpandit
	
	2. Home timeline: To view all posts of user's followers
		http get localhost:5100/posts/hometimeline/{username}
		http get localhost:5100/posts/hometimeline/kpandit
	
	3. Public timeline: To view all posts
		http get localhost:5100/posts/publictimeline




Added Files:

/home/student/Project2/hug/api

The Python source code for each microservice:
/home/student/Project2/hug/api/users.py
/home/student/Project2/hug/api/timeline.py

Procfile:
/home/student/Project2/hug/api/procfile

An initialization script and CSV or SQL schema files for each database:
/home/student/Project2/hug/api/bin/init.sh

Any other configuration files:
Load balance config file: /home/student/Project2/hug/api/haproxy.cfg




