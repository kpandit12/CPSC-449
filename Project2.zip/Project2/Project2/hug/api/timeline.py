# Science Fiction Novel API - Hug Edition
#
# Adapted from "Creating Web APIs with Python and Flask"
# <https://programminghistorian.org/en/lessons/creating-apis-with-python-and-flask>.
#

import configparser
import logging.config
import hug
import requests
import sqlite_utils


# Load configuration
#
config = configparser.ConfigParser()
config.read("./etc/api.ini")
logging.config.fileConfig(config["logging"]["config"], disable_existing_loggers=False)


# Arguments to inject into route functions
#
@hug.directive()
def sqlite(section="sqlite", key="dbfile2", **kwargs):
    dbfile = config[section][key]
    return sqlite_utils.Database(dbfile)


@hug.directive()
def log(name=__name__, **kwargs):
    return logging.getLogger(name)


# Routes
#
@hug.get("/posts/")
def posts(db: sqlite):
    return {"posts": db["posts"].rows}

# Authentication for creating posts
def verifyCreds(username,password):
    # print(username)
    # check that username and password are valid
    print("Inside verifyCreds before call:")
    uname = requests.get(f'http://localhost:5000/users/check_password/{username}/{password}')
    print("Inside verifyCreds:", uname)
    if username  == uname:
        return True
    else:
        return "Invalid username and/or password for user: {0}".format(username)

authentication = hug.authentication.basic(verifyCreds)

@hug.get("/users/check_password/{username}/{password}")
def getCreds(response, username: hug.types.text, password: hug.types.text, db: sqlite):
    print("Inside try:")

    users = sqlite_utils.Database('./var/users.db')
    try:
        for i in users["users"].rows_where("username = ?", [username] and "password = ?", [password]):
            print("ith row: ",list(i))
            username= i.get("username")
            print("Inside getCreds:", username)
            response.status = hug.falcon.HTTP_200
            return {"user": usersname}
    except sqlite_utils.db.NotFoundError:
        response.status = hug.falcon.HTTP_404
    return {"error": str(e)}



@hug.post("/posts/", requires=authentication, status=hug.falcon.HTTP_201)
def create_post(
    username: hug.types.text,
    postmsg: hug.types.text,
    timestamp: hug.types.text,
    repost_url: hug.types.text,
    response,
    db: sqlite,
):
    posts = db["posts"]
    post = {
        "username": username,
        "postmsg": postmsg,
        "timestamp": timestamp,
        "repost_url": repost_url
    }
    try:
        posts.insert(post)
        post["id"] = posts.last_pk
    except Exception as e:
        response.status = hug.falcon.HTTP_409
        return {"error": str(e)}

    response.set_header("Location", f"/posts/{post['id']}")
    return post


@hug.get("/posts/{id}")
def retrieve_post(response, id: hug.types.number, db: sqlite):
    posts = []
    try:
        post = db["posts"].get(id)
        posts.append(post)
    except sqlite_utils.db.NotFoundError:
        response.status = hug.falcon.HTTP_404
    return {"posts": posts}


@hug.get(
    "/search",
    examples=[
        "username=2017",
        "postmsg=Heinlein",
        "timestamp=Star",
    ],
)
def search(request, db: sqlite, logger: log):
    posts = db["posts"]

    conditions = []
    values = []

    if "username" in request.params:
        conditions.append("username = ?")
        values.append(request.params["username"])

    for column in ["postmsg", "timestamp"], "repost_url":
        if column in request.params:
            conditions.append(f"{column} LIKE ?")
            values.append(f"%{request.params[column]}%")

    if conditions:
        where = " AND ".join(conditions)
        logger.debug('WHERE "%s", %r', where, values)
        return {"posts": posts.rows_where(where, values)}
    else:
        return {"posts": posts.rows}


@hug.get("/posts/usertimeline/{username}")
def getUserTimeline(response, username:hug.types.text, db: sqlite):
    posts = []
    try:
        print("username", username)
        for row in db["posts"].rows_where("username = ?", [username]):
            print("rows:", row)
            posts.append(row)
        if len(posts) == 0:
            return {"No posts found for this user"}
        return {"posts": posts}
    except sqlite_utils.db.NotFoundError:
        response.status = hug.falcon.HTTP_404

@hug.get("/posts/publictimeline/")
def getPublicTimeline(response, db: sqlite):
    posts = []
    try:
        return {"posts": db["posts"].rows}
    except sqlite_utils.db.NotFoundError:
        response.status = hug.falcon.HTTP_404

@hug.get("/posts/hometimeline/{username}")
def getHomeTimeline(response, username: hug.types.text, db: sqlite):
    postsA = []
    followerA = []
    users = sqlite_utils.Database('./var/users.db')
    followers = sqlite_utils.Database('./var/followers.db')
    posts = sqlite_utils.Database('./var/posts.db')
    try:
        print("username:", username)
        for i in users["users"].rows_where("username = ?", [username]):
            user_id = i.get("id")
            print("user id:", user_id)
        print("followers:", list(followers["followers"].rows))
        for j in followers["followers"].rows_where("user_id = ?", [user_id]):
            follower_id = j.get("follower_id")
            print("follower id:", follower_id)
            followerA.append(follower_id)
            for k in users["users"].rows_where("id = ?", [follower_id]):
                username = k.get("username")
                print("username:", username)
                for row in posts["posts"].rows_where("username = ?", [username]):
                    print("rows:", row)
                    postsA.append(row)
        if len(postsA) == 0:
            return {"No posts found for this user"}
        return {"posts": postsA}
    except sqlite_utils.db.NotFoundError:
        response.status = hug.falcon.HTTP_404
