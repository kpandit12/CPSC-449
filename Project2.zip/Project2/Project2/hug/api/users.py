# Science Fiction Novel API - Hug Edition
#
# Adapted from "Creating Web APIs with Python and Flask"
# <https://programminghistorian.org/en/lessons/creating-apis-with-python-and-flask>.
#

import configparser
import logging.config

import hug
import sqlite_utils

# Load configuration
#
config = configparser.ConfigParser()
config.read("./etc/api.ini")
logging.config.fileConfig(config["logging"]["config"], disable_existing_loggers=False)



# Arguments to inject into route functions
#users
@hug.directive()
def sqlite(section="sqlite", key="dbfile", **kwargs):
    dbfile = config[section][key]
    print(section)
    print(key)
    return sqlite_utils.Database(dbfile)

@hug.directive()
def log(name=__name__, **kwargs):
    return logging.getLogger(name)

# Routes
@hug.get("/users/")
def users(db: sqlite):
    return {"users": db["users"].rows}


@hug.post("/users/", status=hug.falcon.HTTP_201)
def create_user(
    response,
    username: hug.types.text,
    bio: hug.types.text,
    email_id: hug.types.text,
    password: hug.types.text,
    db: sqlite,
):
    users = db["users"]

    user = {
        "username": username,
        "bio": bio,
        "email_id": email_id,
        "password": password,
    }

    try:
        users.insert(user)
        user["id"] = users.last_pk
    except Exception as e:
        response.status = hug.falcon.HTTP_409
        return {"error": str(e)}

    response.set_header("Location", f"/users/{user['id']}")
    return user


@hug.get("/users/{id}")
def retrieve_user(response, id: hug.types.number, db: sqlite):
    users = []
    try:
        user = db["users"].get(id)
        users.append(user)
    except sqlite_utils.db.NotFoundError:
        response.status = hug.falcon.HTTP_404
    return {"users": users}


@hug.get(
    "/search",
    examples=[
        "username=2017",
        "bio=Heinlein",
        "email_id=Star",
        "password=night",
    ],
)
def search(request, db: sqlite, logger: log):
    users = db["users"]

    conditions = []
    values = []

    if "username" in request.params:
        conditions.append("username = ?")
        values.append(request.params["username"])

    for column in ["bio", "email_id", "password"]:
        if column in request.params:
            conditions.append(f"{column} LIKE ?")
            values.append(f"%{request.params[column]}%")

    if conditions:
        where = " AND ".join(conditions)
        logger.debug('WHERE "%s", %r', where, values)
        return {"users": users.rows_where(where, values)}
    else:
        return {"users": users.rows}

#Followers
@hug.directive()
def sqlite(section="sqlite", key="dbfile1", **kwargs):
    dbfile1 = config[section][key]
    return sqlite_utils.Database(dbfile1)


@hug.get("/followers/")
def followers(db: sqlite):
    return {"followers": db["followers"].rows}


@hug.post("/followers/", status=hug.falcon.HTTP_201)
def create_follower(
    user_id: hug.types.number,
    follower_id: hug.types.number,
    response,
    db: sqlite,
):
    users = sqlite_utils.Database('./var/users.db')
    followers = sqlite_utils.Database('./var/followers.db')
    follower = {
        "user_id": user_id,
        "follower_id": follower_id
    }
    try:
        if user_id == follower_id:
            return {"error": str("both ids cannot be same")}
        else:
            if len(list(users['users'].rows_where("id = ?", [user_id]))) > 0 and len(list(users['users'].rows_where("id = ?", [follower_id]))):
                followers['followers'].insert(follower)
                follower["id"] = followers['followers'].last_pk
            else:
                return {"error": str("follower or user does not exist")}

    except sqlite_utils.db.NotFoundError:
        response.status = hug.falcon.HTTP_404
    response.set_header("Location", f"/followers/{follower['id']}")
    return follower


@hug.get("/followers/{id}")
def retrieve_user(response, id: hug.types.number, db: sqlite):
    users = []
    try:
        follower = db["followers"].get(id)
        followers.append(follower)
    except sqlite_utils.db.NotFoundError:
        response.status = hug.falcon.HTTP_404
    return {"followers": followers}


@hug.get(
    "/search",
    examples=[
        "user_id=test",
        "follower_id=Heinlein",
    ],
)
def search(request, db: sqlite, logger: log):
    followers = db["followers"]

    conditions = []
    values = []

    if "user_id" in request.params:
        conditions.append("user_id = ?")
        values.append(request.params["user_id"])

    if "follwer_id_id" in request.params:
        conditions.append("user_id = ?")
        values.append(request.params["follower_id"])


    if conditions:
        where = " AND ".join(conditions)
        logger.debug('WHERE "%s", %r', where, values)
        return {"followers": users.rows_where(where, values)}
    else:
        return {"followers": users.rows}

@hug.delete("/followers/", status=hug.falcon.HTTP_201)
def remove_follower(
    user_id: hug.types.number,
    follower_id: hug.types.number,
    response,
    db: sqlite,
):
    followers = sqlite_utils.Database('./var/followers.db')
    follower = {
        "user_id": user_id,
        "follower_id": follower_id
    }
    try:
        followers['followers'].delete(follower_id)
        return {"follower": follower}
    except sqlite_utils.db.NotFoundError:
        response.status = hug.falcon.HTTP_404
        return {"error": str("Could not find follower_id in database!")}
